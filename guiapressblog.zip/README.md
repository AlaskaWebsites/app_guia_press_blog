# Blog-Guia-Press

A Plataforma Blog Guia Press, como o nome diz, é um blog onde é possivel criar determinadas categorias e nelas serão cadastrados artigos.

<img src="./design.png" alt="Blog-Guia-Press">

# Recursos

* O aplicativo foi desenvolvido com JavaScrip, CSS, HTML, EJS, MySQL e Express.js.

# Uso

1. Clone o repositório do GitHub.
2. Abra o projeto no seu editor de código.
3. Instale o pacote do projeto com npm install(É necessário MySQL instalado).
4. Inicie o MySQL Workbench.
5. Depois de instalado os pacotes, basta dar um npm start para iniciar o projeto na porta localhost:3000.

# Créditos

Este projeto foi criado por Alaska Websites.